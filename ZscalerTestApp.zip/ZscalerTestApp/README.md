# Zscaler Request Tester
### ASP.NET MVC + Web API — .NET Framework 4.8 — IIS Ready

A single-project web application to reproduce and demonstrate the Zscaler
HTTP/2 SSL inspection issue. Sends real GET and POST requests to a local API
and displays full request/response details including headers, protocol version,
and client IP — making it easy to capture evidence for the IT ticket.

---

## Prerequisites

- Visual Studio 2019 or 2022
- .NET Framework 4.8 (included in Windows 10/11)
- IIS enabled on the machine (for production hosting)
- NuGet Package Manager

---

## Step 1 — Open and Restore

1. Open `ZscalerTestApp.sln` (or open the `.csproj` directly in Visual Studio)
2. Right-click the solution → **Restore NuGet Packages**
3. Required packages (auto-installed):
   - `Microsoft.AspNet.Mvc 5.3.0`
   - `Microsoft.AspNet.WebApi 5.3.0`
   - `Microsoft.AspNet.WebApi.WebHost 5.3.0`
   - `Newtonsoft.Json 13.0.3`

---

## Step 2 — Run Locally (Quick Test)

Press **F5** in Visual Studio — it will launch in IIS Express.

- Home page:  `http://localhost:{port}/`
- GET endpoint:  `http://localhost:{port}/api/test/data`
- POST endpoint: `http://localhost:{port}/api/test/submit`

---

## Step 3 — Publish to IIS

### Enable IIS (if not already)
```
Control Panel → Programs → Turn Windows features on or off
→ Internet Information Services → check all sub-features
→ Also check: Application Development Features → ASP.NET 4.8
```

### Publish from Visual Studio
1. Right-click project → **Publish**
2. Target: **IIS, FTP, etc.**
3. Publish method: **Web Deploy** or **File System**
4. Set the target folder (e.g. `C:\inetpub\wwwroot\ZscalerTester`)
5. Click **Publish**

### Configure IIS Site
1. Open **IIS Manager** (`inetmgr`)
2. Right-click **Sites** → **Add Website**
   - Site name: `ZscalerTester`
   - Physical path: `C:\inetpub\wwwroot\ZscalerTester`
   - Port: `8080` (or any available port)
3. Click **OK**
4. Select the site → **Application Pool** → change to `.NET CLR v4.0`, **Integrated** pipeline

### Enable HTTPS (to trigger Zscaler SSL inspection)
1. In IIS Manager → select the site → **Bindings** → **Add**
2. Type: `https`, Port: `443`, select your SSL certificate
3. If no cert: use a self-signed cert via IIS → **Server Certificates** → **Create Self-Signed Certificate**

---

## Step 4 — Using the App to Reproduce the Zscaler Issue

1. Open the hosted URL in Chrome/Edge
2. Open **DevTools → Network tab** (F12)
3. Enable the **Protocol** column (right-click column headers → Protocol)
4. Click **"Fetch User Data"** (GET) — observe the request in Network tab
5. Click **"Submit Payload"** (POST) — observe the request in Network tab

### What to look for
| DevTools | What you see |
|----------|-------------|
| Protocol column | `h2` on both requests |
| Status (on fail) | `net::ERR_HTTP2_PROTOCOL_ERROR` |
| Response (on fail) | Empty — no body, no headers |
| On retry | Succeeds — same request works |

### The app also shows (in UI when successful)
- All request headers **as received by the server** — Zscaler proxy headers visible here
- Server-side protocol (`HTTP/1.1` or `HTTP/2`)
- Client IP (shows Zscaler proxy IP, not real client IP)
- Request ID and timestamp per call

---

## API Endpoints Reference

### GET /api/test/data
Returns a list of fake users plus all request headers.

**Response:**
```json
{
  "success": true,
  "method": "GET",
  "timestamp": "2026-03-14T10:23:45.123Z",
  "requestId": "A1B2C3D4E5F6",
  "endpoint": "/api/test/data",
  "protocol": "HTTP/1.1",
  "userAgent": "Mozilla/5.0 ...",
  "clientIp": "10.x.x.x",
  "requestHeaders": {
    "Host": "yourserver.com",
    "X-Forwarded-For": "...",
    "X-ZScaler-...": "..."
  },
  "data": {
    "users": [...],
    "total": 3,
    "message": "GET request successful"
  }
}
```

### POST /api/test/submit
Accepts a JSON payload and echoes it back.

**Request body:**
```json
{
  "name": "Test User",
  "email": "test@company.com",
  "message": "Test message",
  "priority": "high"
}
```

**Response:** HTTP 201 Created — echoes back received payload plus request metadata.

---

## Evidence to Capture for IT Ticket

When the error occurs, capture:

1. **DevTools HAR file** — Network tab → right-click → Save all as HAR
2. **Screenshot of Network tab** showing `ERR_HTTP2_PROTOCOL_ERROR` with `h2` protocol
3. **UI screenshot** — shows request headers and `ZTUNNEL_2_0_DTLS1_2` will appear in Zscaler logs

---

## Project Structure

```
ZscalerTestApp/
├── App_Start/
│   ├── RouteConfig.cs          — MVC routing
│   └── WebApiConfig.cs         — Web API routing + JSON config
├── Controllers/
│   ├── ApiController.cs        — GET /api/test/data, POST /api/test/submit
│   └── HomeController.cs       — Serves the UI
├── Models/
│   └── Models.cs               — ApiResponse, PostPayload
├── Views/
│   ├── Home/Index.cshtml       — Main UI (self-contained, no layout)
│   └── Shared/_Layout.cshtml   — Minimal layout
├── Global.asax / Global.asax.cs
├── Web.config
├── packages.config
└── ZscalerTestApp.csproj
```
