using System.Collections.Generic;

namespace ZscalerTestApp.Models
{
    public class ApiResponse
    {
        public bool   Success          { get; set; }
        public string Method           { get; set; }
        public string Timestamp        { get; set; }
        public string RequestId        { get; set; }
        public string Endpoint         { get; set; }
        public string Protocol         { get; set; }
        public string UserAgent        { get; set; }
        public string ClientIp         { get; set; }
        public Dictionary<string, string> RequestHeaders { get; set; }
        public object Data             { get; set; }
    }

    public class PostPayload
    {
        public string Name     { get; set; }
        public string Email    { get; set; }
        public string Message  { get; set; }
        public string Priority { get; set; }
    }
}
