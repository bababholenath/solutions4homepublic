using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using ZscalerTestApp.Models;

namespace ZscalerTestApp.Controllers
{
    [RoutePrefix("api/test")]
    public class TestApiController : ApiController
    {
        // GET api/test/data
        [HttpGet]
        [Route("data")]
        public IHttpActionResult GetData()
        {
            var requestHeaders = new Dictionary<string, string>();
            foreach (var key in HttpContext.Current.Request.Headers.AllKeys)
            {
                requestHeaders[key] = HttpContext.Current.Request.Headers[key];
            }

            var response = new ApiResponse
            {
                Success     = true,
                Method      = "GET",
                Timestamp   = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                RequestId   = Guid.NewGuid().ToString("N").Substring(0, 12).ToUpper(),
                Endpoint    = "/api/test/data",
                Protocol    = HttpContext.Current.Request.ServerVariables["SERVER_PROTOCOL"],
                UserAgent   = HttpContext.Current.Request.UserAgent,
                ClientIp    = GetClientIp(),
                RequestHeaders = requestHeaders,
                Data = new
                {
                    users = new[]
                    {
                        new { id = 1, name = "Arjun Mehta",    role = "Developer",  dept = "Engineering", active = true  },
                        new { id = 2, name = "Priya Sharma",   role = "QA Lead",    dept = "Testing",     active = true  },
                        new { id = 3, name = "Rohan Verma",    role = "DevOps",     dept = "Infra",       active = false }
                    },
                    total   = 3,
                    page    = 1,
                    message = "GET request successful — check network tab for protocol details"
                }
            };

            return Ok(response);
        }

        // POST api/test/submit
        [HttpPost]
        [Route("submit")]
        public IHttpActionResult PostData([FromBody] PostPayload payload)
        {
            if (payload == null)
                return BadRequest("Payload cannot be empty");

            var requestHeaders = new Dictionary<string, string>();
            foreach (var key in HttpContext.Current.Request.Headers.AllKeys)
            {
                requestHeaders[key] = HttpContext.Current.Request.Headers[key];
            }

            var response = new ApiResponse
            {
                Success     = true,
                Method      = "POST",
                Timestamp   = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ"),
                RequestId   = Guid.NewGuid().ToString("N").Substring(0, 12).ToUpper(),
                Endpoint    = "/api/test/submit",
                Protocol    = HttpContext.Current.Request.ServerVariables["SERVER_PROTOCOL"],
                UserAgent   = HttpContext.Current.Request.UserAgent,
                ClientIp    = GetClientIp(),
                RequestHeaders = requestHeaders,
                Data = new
                {
                    received = new
                    {
                        payload.Name,
                        payload.Email,
                        payload.Message,
                        payload.Priority
                    },
                    saved     = true,
                    recordId  = Guid.NewGuid().ToString("N").Substring(0, 8).ToUpper(),
                    message   = "POST request successful — payload received and echoed back"
                }
            };

            return Content(HttpStatusCode.Created, response);
        }

        private string GetClientIp()
        {
            var ctx = HttpContext.Current;
            string ip = ctx.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(ip))
                ip = ctx.Request.ServerVariables["REMOTE_ADDR"];
            return ip ?? "unknown";
        }
    }
}
